<?php
    include'header.php';
?>
<!-- <section class="hero is-info is-medium is-bold">
        <div class="hero-body">
            <div class="container has-text-centered">
                <h1 class="title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, <br>sed eiusmod tempor incididunt ut labore et dolore magna aliqua</h1>
            </div>
        </div>
    </section> -->
<?php
    include'body.php';
?>
                                                <article>
   
                                                    <p class="is-size-3">Airport pick up service</p>
                                                    <p class ="is-size-5">Mybook has partnered up with Uber to deliver your choice of book for your convenience at airport whether you are just arrive to Australia or ready to take off to your adventure or perhaps relaxed holiday on the beach! 
                                                    Service is optional and available throughout Australia. 
                                                    </p>

                                                </article>
                <?php

    include'footer.php';
?>