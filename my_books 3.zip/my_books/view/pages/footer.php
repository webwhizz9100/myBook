
   <footer class="footer">
        <div id="navbarExampleTransparentExample" class="navbar-menu">
                <div class="navbar-start has-text-centered">
                    <a class="navbar-item" href="http://localhost:7888/my_books/view/pages/disclaimer.php">
                    Disclaimer
                        </a>
                    <a class="navbar-item" href="http://localhost:7888/my_books/view/pages/retn.php">
                        Return/Refund Policy
                    </a> 
                    <a class="navbar-item" href="http://localhost:7888/my_books/view/pages/ap.php">
                    Airport pickup service
                    </a>
                    <a class="navbar-item" href="http://localhost:7888/my_books/View/Pages/mile.php">
                        Earn Mileage 
                    </a>

</div>            
        <div class="container">
            <div class="content has-text-centered">
                <p>
                    <a href="">
                        <i class="fab fa-facebook-square fa-2x"></i>
                    </a>
                    <a href="">
                        <i class="fab fa-twitter-square fa-2x"></i>
                    </a>
                    <a href="">
                        <i class="fab fa-instagram fa-2x"></i>
                    </a>
                    <a href="">
                        <i class="fab fa-snapchat fa-2x"></i>
                    </a>
                </p>
                <p>
                    <a href="https://bulma.io">
                        <img src="https://bulma.io/images/made-with-bulma.png" alt="Made with Bulma" width="128" height="24">
                    </a>
                </p>
            </div>
        </div>
    </footer>
        <script src="../js/bulma.js"></script>
</body>

</html>