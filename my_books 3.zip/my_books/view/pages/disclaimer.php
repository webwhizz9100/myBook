<?php
    include'header.php';
?>



  <?php
    include'body.php';
?>
                                                    <article>        
                                                            <p class ="is-size-3">Disclaimer</p>
                                                            <p class ="is-size-5">We are working on  our best possible effort to provide pleasant shopping experience with us. </p> 
                                                            <p class ="is-size-3">Privacy
                                                            </p></br>
                                                           <p class ="is-size-5">At Mybook  we respect your privacy. Information collected for ordering , delivery purpose is solely stays within company, We will not transfer your privacy details unless  required by   law enforcement.   

                                                            </p></br>
                                                            <p class ="is-size-3">Online security /scams and malwares
                                                            </p></br>
                                                             <p"is-size-5">
                                                             Mybook  will take appropriate cautious to represent safe website.
                                                            However this can not be holeproof. Please use your own safe measurement when using the site.

                                                            </p>   
                                                             <p class ="is-size-3">Delivery</p>
                                                             <p class ="is-size-5">Our aim is to deliver the product on time. Unfortunately, due to traffic, road condition and weather condition may play against the part. We will notify you as this may arise as soon as possible. On the event of delaying delivery  fee is waived for customer who chosen airport delivery and  we will offer  $20 credit.
                                                             </p>
                                                    </article>         
                                                                                    
                <?php

    include'footer.php';
?>