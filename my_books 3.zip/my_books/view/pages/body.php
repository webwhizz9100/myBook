<div class="container">
        <!-- START ARTICLE FEED -->
        <section class="articles">
            <div class="column is-8 is-offset-2">
                <!-- START ARTICLE -->
                <div class="card article">
                    <div class="card-content">
                        <div class="media">
                        <div class="media-center">
                                <img src="../images/pics/bg.jpg" class="author-image" alt="Placeholder image">
                            </div>
                           
                        </div>
                        <div class="content article-body has-text-centered">
                                                   <!-- content -->
                                                  
                        </div>
                    </div>
                </div>