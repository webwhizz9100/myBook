<?php
    include'header.php';
?>


 <?php
    include'body.php';
?>                      
                            <article>  
                              <p class ="is-size-3">Return/refund policy </p></br> 
                               <p class ="is-size-5">We will refund /exchange if you’re  book..</p>
                               
                                        <ol>
                                            <li>Has  arrived damaged</li>
                                            <li>Has wrong description</li>
                                            <li>Has faulty</li>
                                        </ol>   
                               
                            </br>
                                <p class ="is-size-5">If you like refund or exchange get in touch with us wIthin 2 weeks of purchase. 
                                Please be mindful we do not generally refund for change of mind.

                                </p>
                            </article>    

                      
                <?php

    include'footer.php';
?>