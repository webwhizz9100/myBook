<?php
    include'header.php';
?>



   <?php
    include'body.php';
?>                                              <article>
                                                            <p class="is-size-3">Earn Mileage</h3>
                                                                                        <p class ="is-size-5">Mybook has associated with Qantas frequent flyer point for our travel beloved readers. 
                                                            You need to sign up with frequent flyer  program in order to earn points. Customer who place their first order with us receives 500 welcome points.  The points will be issued  after transaction has processed within 30 days then on every order placed . Please note that points will only be issue when transaction has successfully established.
                                                            </p><br>
                                                            <p class ="is-size-5">To enquire , track / claim  of your earned point please refer Qantas frequent flyer.com.au. My book will carry no liability once points are issued and points cannot be redeemed as credit/ transaction with us.
                                                            </p>
                                                </article>
                <?php

    include'footer.php';
?>